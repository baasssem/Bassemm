let etudiant = [];
let btnValider;

function afficherTableau() {
  let tbody = document.querySelector("tbody");
  let newHTML = "";
  for (let i = 0; i < etudiant.length; i++) {
    
    newHTML += "<tr>";
    newHTML +=
    "<th scope='row'>" + etudiant[i].Nom + " " + etudiant[i].Prenom + "</th>";
    newHTML += "<td>" + etudiant[i].Email + "</td>";
    newHTML += "<td>" +
      (parseInt(etudiant[i].Note1) +
       parseInt(etudiant[i].Note2) +
       parseInt(etudiant[i].Note3)) / 3 +"</td>";
       
    newHTML += "<td>" + "<button type ='button' style='border: none' onClick='voirdetails("+i+")'><img src='icon.png' width='25'/></button>" + "</td>";
    newHTML += "<td>" + "<button type ='button' style='border: none' onClick='supression("+i+")'><img src='icon1.png' width='25'/></button>" + "</td>";
    
    newHTML += "</tr>";
  }
  tbody.innerHTML = newHTML;
}

function voirdetails(i) {
  alert(
    "Classe est " +
      etudiant[i].Classe +
      "  Note 1 = " +
      etudiant[i].Note1 +
      "  Note 2 = " +
      etudiant[i].Note2 +
      "  Note 3 = " +
      etudiant[i].Note3
  );
}
function ajoutEtudiant() {
  const NomVal   = document.getElementById("Nom").value;
  const PrenomVal= document.getElementById("Prenom").value;
  const EmailVal = document.getElementById("Email").value;
  const ClasseVal= document.getElementById("Classe").value;
  const Note1Val = document.getElementById("Note1").value;
  const Note2Val = document.getElementById("Note2").value;
  const Note3Val = document.getElementById("Note3").value;

 
  const newEtudiant = new Etudiant(
    NomVal,
    PrenomVal,
    EmailVal,
    ClasseVal,
    Note1Val,
    Note2Val,
    Note3Val
  );

  etudiant.push(newEtudiant);
  console.table(etudiant);

  afficherTableau();
}
function supression(i) {
  document.getElementById("tablee").deleteRow(i + 1);
}

function index() {
  etudiant = [];
  btnValider = document.getElementById("btnValider");
  btnValider.addEventListener("click", ajoutEtudiant);
}



function main() {
  index();
  afficherTableau();
}

window.addEventListener("load", main); 