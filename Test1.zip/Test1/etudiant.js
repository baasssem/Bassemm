class Etudiant {
  constructor(Nom, Prenom, Email, Classe, Note1, Note2, Note3) {
    this.Nom = Nom;
    this.Prenom = Prenom;
    this.Email = Email;
    this.Classe = Classe;
    this.Note1 = Note1;
    this.Note2 = Note2;
    this.Note3 = Note3;
  }
}
